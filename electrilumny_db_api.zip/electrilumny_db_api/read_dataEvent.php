<?php

require_once 'connection.php';
        
    $query_readDataEvent = "SELECT * FROM event";
    $result = mysqli_query($conn,$query_readDataEvent);
    $response = array();

    while($row = mysqli_fetch_array($result)){
        array_push($response, array(
            "nama_event" => $row[1],
            "deskripsi_acara" => $row[3],
            "tgl_pelaksanaan" => $row[2],
            "lokasi_acara" => $row[4],
        ));
    }

echo json_encode(array('server_response' => $response));
mysqli_close($conn);
?>
