<?php

require_once 'connection.php';
        
if($conn){
    $nama_event = $_POST['nama_event'];
    $tgl_pelaksanaan = $_POST['tgl_pelaksanaan'];
    $deskripsi_acara = $_POST['deskripsi_acara'];
    $lokasi_acara = $_POST['lokasi_acara'];

    $sql_createEvent = "insert into event(nama_event, tgl_pelaksanaan, deskripsi_acara, lokasi_acara) values ('$nama_event', '$tgl_pelaksanaan', '$deskripsi_acara', '$lokasi_acara')";


    if($nama_event != "" && $tgl_pelaksanaan != "" && $deskripsi_acara != "" && $lokasi_acara != "" ){
        $result = mysqli_query($conn, $sql_createEvent);
        $response = array();
 
        if($result) {
            $result = mysqli_query($conn, $sql_register);
            $response = array();
            
            array_push($response, array(
                'status' => 'OK'
            ));
        } else{
            array_push($response, array(
                'status' => 'FAILED 1'
            ));
        }
    } else{
        array_push($response, array(
            'status' => 'FAILED'
        ));
    }
}else{
    array_push($response, array(
        'status' => 'FAILED 3'
    ));
}

echo json_encode(array('server_response' => $response));
mysqli_close($conn);
?>
