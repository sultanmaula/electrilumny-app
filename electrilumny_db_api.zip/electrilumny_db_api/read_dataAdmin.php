<?php

require_once 'connection.php';
        
    $query_readDataAdmin = "SELECT * FROM user";
    $result = mysqli_query($conn,$query_readDataAdmin);
    $response = array();

    while($row = mysqli_fetch_array($result)){
        array_push($response, array(
            "id" => $row[0],
            "nama_lengkap" => $row[1],
            "email" => $row[2],
            "th_angkatan" => $row[5],
            "jenis_pendidikan" => $row[6],
        ));
    }

echo json_encode(array('server_response' => $response));
mysqli_close($conn);
?>
