<?php 
    require_once 'connection.php';
        
    if($conn){
        $email = $_POST['email'];
        $password = $_POST['password'];

        $sql_login = "SELECT * FROM user WHERE email = '$email' AND password = '$password'";
        $result = mysqli_query($conn, $sql_login);
        $response = array();

        $row = mysqli_num_rows($result);
        $data = mysqli_fetch_assoc($result);

        if($row > 0){
            array_push($response, array(
                'status' => 'OK',
                // 'nama_lengkap' => $data['nama_lengkap'],
                // 'email' => $data['email'],
                // 'password' => $data['password'],
                'role' => $data['role']
            ));
        } else{
            array_push($response, array(
                'status' => 'FAILED'
            ));
        }
    }else{
        array_push($response, array(
            'status' => 'FAILED'
        ));
    }

    echo json_encode(array('server_response' => $response));
    mysqli_close($conn);
?>
