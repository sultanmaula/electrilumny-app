<?php

require_once 'connection.php';
        
if($conn){
    $nama_lengkap = $_POST['nama_lengkap'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $role = $_POST['role'];
    $th_angkatan = $_POST['th_angkatan'];
    $jenis_pendidikan = $_POST['jenis_pendidikan'];

    $sql_register = "insert into user(nama_lengkap, email, password, role, th_angkatan, jenis_pendidikan) values ('$nama_lengkap', '$email', '$password', '$role', '$th_angkatan', '$jenis_pendidikan')";


    if($nama_lengkap != "" && $email != "" && $password != "" && $role != "" && $th_angkatan != "" && $jenis_pendidikan != ""){
        $result = mysqli_query($conn, $sql_register);
        $response = array();
 
        if($result) {
            $result = mysqli_query($conn, $sql_register);
            $response = array();
            
            array_push($response, array(
                'status' => 'OK'
            ));
        } else{
            array_push($response, array(
                'status' => 'FAILED 1'
            ));
        }
    } else{
        array_push($response, array(
            'status' => 'FAILED'
        ));
    }
}else{
    array_push($response, array(
        'status' => 'FAILED 3'
    ));
}

echo json_encode(array('server_response' => $response));
mysqli_close($conn);
?>
